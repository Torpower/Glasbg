package bg.glasbg.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF18212F)
private val Muted = Color(0xFF697586)
private val Accent = Color(0xFF3568F5)
private val Surface = Color(0xFFF4F6FA)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GlasBgScreen() }
    }
}

@Composable
fun GlasBgScreen() {
    var enabled by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf("Автоматичен") }
    var sourceLanguage by remember { mutableStateOf("Автоматично разпознаване") }
    var originalVolume by remember { mutableFloatStateOf(0.20f) }
    var dubVolume by remember { mutableFloatStateOf(0.90f) }
    var status by remember { mutableStateOf("Готово за настройка") }

    MaterialTheme(colorScheme = lightColorScheme(primary = Accent, background = Surface, surface = Color.White)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Surface) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(52.dp).background(Accent, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                        Text("ГБ", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp)
                    }
                    Column(Modifier.weight(1f)) {
                        Text("ГласБГ AI", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Ink)
                        Text("Превод и дублаж на български", color = Muted, fontSize = 13.sp)
                    }
                    Surface(color = Color(0xFFE7F7ED), shape = RoundedCornerShape(50)) {
                        Text("ПРОТОТИП", modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), color = Color(0xFF167345), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(24.dp)) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(if (enabled) "Дублажът е включен" else "Готов ли си да разбираш всичко?", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Ink)
                        Text(if (enabled) "Това е демонстрационен режим — обработката на звук още не е свързана." else "Пусни видео в поддържано приложение, а тук настрой желания режим.", color = Muted, fontSize = 14.sp)
                        Button(onClick = { enabled = !enabled; status = if (enabled) "Демонстрационният режим е включен" else "Дублажът е спрян" }, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(16.dp)) {
                            Text(if (enabled) "Спри дублажа" else "Включи дублажа", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Box(Modifier.size(8.dp).background(if (enabled) Color(0xFF20A464) else Color(0xFFB9C1CE), RoundedCornerShape(50)))
                            Text(status, color = Muted, fontSize = 12.sp)
                        }
                    }
                }

                SectionTitle("Режим на работа", "Избери как да се обработва звукът")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf("Онлайн", "Офлайн", "Автоматичен").forEach { option ->
                        val selected = mode == option
                        Surface(onClick = { mode = option }, modifier = Modifier.weight(1f), color = if (selected) Accent else Color.White, shape = RoundedCornerShape(14.dp), border = if (selected) null else androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE0E5ED)) ) {
                            Text(option, modifier = Modifier.padding(vertical = 14.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = if (selected) Color.White else Ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                    }
                }

                SectionTitle("Език на оригинала", "Езикът на дублажа е български")
                var expanded by remember { mutableStateOf(false) }
                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                    OutlinedTextField(value = sourceLanguage, onValueChange = {}, readOnly = true, label = { Text("Входящ език") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = OutlinedTextFieldDefaults.colors(unfocusedContainerColor = Color.White, focusedContainerColor = Color.White))
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        listOf("Автоматично разпознаване", "Английски", "Немски", "Испански", "Френски", "Италиански", "Турски", "Руски", "Български").forEach { lang ->
                            DropdownMenuItem(text = { Text(lang) }, onClick = { sourceLanguage = lang; expanded = false })
                        }
                    }
                }

                SectionTitle("Звук", "Настрой съотношението между оригинала и дублажа")
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row { Text("Оригинален звук", color = Ink, fontWeight = FontWeight.Medium); Spacer(Modifier.weight(1f)); Text("${(originalVolume * 100).toInt()}%", color = Muted) }
                        Slider(value = originalVolume, onValueChange = { originalVolume = it })
                        Row { Text("Български дублаж", color = Ink, fontWeight = FontWeight.Medium); Spacer(Modifier.weight(1f)); Text("${(dubVolume * 100).toInt()}%", color = Muted) }
                        Slider(value = dubVolume, onValueChange = { dubVolume = it })
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF0FF)), shape = RoundedCornerShape(20.dp)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.Top) {
                        Text("✦", color = Accent, fontSize = 23.sp)
                        Column {
                            Text("Умен избор на глас", color = Ink, fontWeight = FontWeight.Bold)
                            Text("Планирано: автоматичен избор на женски, мъжки или детски тембър според гласа и запазване на емоцията, доколкото е възможно.", color = Muted, fontSize = 13.sp)
                        }
                    }
                }
                Text("Важно: това е началният интерфейс. Реалният превод, синтезът на реч, офлайн езиковите модели и прихващането на вътрешния звук предстои да бъдат добавени. Android не разрешава прихващане на аудио от всяко приложение във всички случаи.", color = Muted, fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}
